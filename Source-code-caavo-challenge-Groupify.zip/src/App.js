import './App.css';
import HomePage from './views/HomePage';

function App() {
  return (
    <div className="App">
      <header className="header">
        <h1>
          Groupify
        </h1>
      </header>
      <HomePage />
    </div>
  );
}

export default App;
